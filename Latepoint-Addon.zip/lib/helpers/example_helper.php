<?php 

class OsExampleHelper {
  
  function __construct(){
  }

  public static function example_call(){
    $example_var = 'This is example variable';
    return $example_var;
  }
}